import java.awt.Component;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;


public class Start {

	protected Shell shell;
	private Text height;
	private Text weight;
	public static PatientRecord record = new PatientRecord();
	
	
	public static PatientRecord getRecord() {
		return record;
	}

	public static void setRecord(PatientRecord record) {
		record = record;
	}

	private Text age;
	private Text bsPulse;
	private Text bsFEV1;
	private Text bsHR;
	private Text bsfvp;
	/**
	 * Launch the application.
	 * @param args
	 * @wbp.parser.entryPoint
	 */
	public static void NewScreen() {
		try {
			Start window = new Start();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	
	public int findBMI(int height, int weight){
		
		float t = height /100;
		return Math.round((weight/t)/t);
	}
	
	protected void createContents() {
		shell = new Shell();
		shell.setTouchEnabled(true);
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		shell.setSize(835, 559);
		shell.setText("SWT Application");
		
		Label lblPleaseFillThe = new Label(shell, SWT.NONE);
		lblPleaseFillThe.setAlignment(SWT.CENTER);
		lblPleaseFillThe.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblPleaseFillThe.setFont(SWTResourceManager.getFont("Andalus", 16, SWT.BOLD));
		lblPleaseFillThe.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblPleaseFillThe.setBounds(269, 27, 300, 37);
		lblPleaseFillThe.setText("Profile Data");
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblNewLabel.setBounds(22, 74, 65, 20);
		lblNewLabel.setText("Gender:");
		
		Combo gender = new Combo(shell, SWT.NONE);
		gender.setBackground(SWTResourceManager.getColor(204, 255, 255));
		gender.setBounds(125, 78, 97, 23);
		gender.setText("Male");
		gender.add("Male");
		gender.add("Female");
		
		Label lblHeightInCm = new Label(shell, SWT.NONE);
		lblHeightInCm.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblHeightInCm.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblHeightInCm.setBounds(267, 74, 97, 21);
		lblHeightInCm.setText("Height in cm:\r\n");
		
		height = new Text(shell, SWT.BORDER);
		height.setBackground(SWTResourceManager.getColor(204, 255, 255));
		height.setBounds(388, 78, 61, 25);
		
		Label lblWeightInKg = new Label(shell, SWT.NONE);
		lblWeightInKg.setText("Weight in kg:\r\n");
		lblWeightInKg.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblWeightInKg.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblWeightInKg.setBounds(269, 113, 95, 25);
		
		weight = new Text(shell, SWT.BORDER);
		weight.setBackground(SWTResourceManager.getColor(204, 255, 255));
		weight.setBounds(388, 117, 61, 25);
		
		Combo currMed = new Combo(shell, SWT.NONE);
		currMed.setBackground(SWTResourceManager.getColor(204, 255, 255));
		currMed.setBounds(173, 394, 453, 23);
		currMed.setText("Unknown");
		currMed.add("Unknown");
		currMed.add("Prescribed Inhaler (Azithromycin or Roflumilast) + rescue Inhaler As Needed.");
		currMed.add("Pill for Controlling Exacerbations + Prescribed Inhaler + Rescue Inhaler As Needed");
		currMed.add("Rescue Inhaler Or Nebulizer As Needed For Breathing");
		currMed.setText("Rescue Inhaler Or Nebulizer As Needed For Breathing");
		
		Combo copdStage = new Combo(shell, SWT.NONE);
		copdStage.setBackground(SWTResourceManager.getColor(204, 255, 255));
		copdStage.setBounds(173, 423, 453, 23);
		copdStage.add("GOLD STAGE 1 (FEV1 80 - 100% Predicted)");
		copdStage.add("GOLD STAGE 2 (FEV1 50-79% Predicted)");
		copdStage.add("GOLD STAGE 3 (FEV1 30-49% Predicted)");
		copdStage.add("GOLD STAGE 4 (FEV1 < 30% Predicted, or < 50% Predicted, Chronic Respiratory Failure)");
		copdStage.setText("GOLD STAGE 1 (FEV1 80 - 100% Predicted)");
	
		
		Label agelabel = new Label(shell, SWT.NONE);
		agelabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		agelabel.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		agelabel.setForeground(SWTResourceManager.getColor(0, 0, 0));
		agelabel.setBounds(22, 113, 35, 25);
		agelabel.setText("Age:");
		
		age = new Text(shell, SWT.BORDER);
		age.setBackground(SWTResourceManager.getColor(204, 255, 255));
		age.setBounds(125, 117, 61, 25);
		
		Label lblCurrentMedication = new Label(shell, SWT.NONE);
		lblCurrentMedication.setText("Current Medication:");
		lblCurrentMedication.setForeground(SWTResourceManager.getColor(0, 0, 0));
		lblCurrentMedication.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCurrentMedication.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCurrentMedication.setBounds(22, 392, 145, 25);
		
		Label lblCopdGoldStage = new Label(shell, SWT.NONE);
		lblCopdGoldStage.setText("COPD GOLD Stage:");
		lblCopdGoldStage.setForeground(SWTResourceManager.getColor(0, 0, 0));
		lblCopdGoldStage.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCopdGoldStage.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCopdGoldStage.setBounds(22, 424, 145, 25);
		
		Label riskslabel = new Label(shell, SWT.NONE);
		riskslabel.setText("Select the most risk factors: (4 maximum)");
		riskslabel.setForeground(SWTResourceManager.getColor(0, 0, 0));
		riskslabel.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		riskslabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		riskslabel.setBounds(22, 154, 278, 25);
		
		Button btnCheckButton = new Button(shell, SWT.CHECK);
		btnCheckButton.setBounds(22, 197, 145, 16);
		btnCheckButton.setText("Acid Reflux");
		btnCheckButton.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
	
		
		Button btnAsthma = new Button(shell, SWT.CHECK);
		btnAsthma.setBounds(22, 219, 93, 16);
		btnAsthma.setText("Asthma");
		btnAsthma.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_1 = new Button(shell, SWT.CHECK);
		btnCheckButton_1.setBounds(22, 241, 93, 16);
		btnCheckButton_1.setText("Diabetes");
		btnCheckButton_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_2 = new Button(shell, SWT.CHECK);
		btnCheckButton_2.setBounds(203, 197, 133, 16);
		btnCheckButton_2.setText("High Blood Pressure");
		btnCheckButton_2.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_3 = new Button(shell, SWT.CHECK);
		btnCheckButton_3.setBounds(203, 219, 153, 16);
		btnCheckButton_3.setText("Pulmonary Hypertension");
		btnCheckButton_3.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_4 = new Button(shell, SWT.CHECK);
		btnCheckButton_4.setBounds(203, 241, 153, 16);
		btnCheckButton_4.setText("Coronary Artery Disease");
		btnCheckButton_4.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_5 = new Button(shell, SWT.CHECK);
		btnCheckButton_5.setBounds(412, 197, 201, 16);
		btnCheckButton_5.setText("Hospitalized for COPD in Last Year");
		btnCheckButton_5.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_6 = new Button(shell, SWT.CHECK);
		btnCheckButton_6.setBounds(412, 219, 225, 16);
		btnCheckButton_6.setText("Needs Help Performing Daily Activities");
		btnCheckButton_6.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_7 = new Button(shell, SWT.CHECK);
		btnCheckButton_7.setBounds(412, 241, 209, 16);
		btnCheckButton_7.setText("2 or More Exacerbations In Last Year");
		btnCheckButton_7.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_8 = new Button(shell, SWT.CHECK);
		btnCheckButton_8.setBounds(22, 263, 93, 16);
		btnCheckButton_8.setText("Lives Alone");
		btnCheckButton_8.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		
		Button btnCheckButton_9 = new Button(shell, SWT.CHECK);
		btnCheckButton_9.setBounds(203, 263, 153, 16);
		btnCheckButton_9.setText("Chronic Kidney Disease");
		btnCheckButton_9.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_10 = new Button(shell, SWT.CHECK);
		btnCheckButton_10.setBounds(412, 263, 201, 16);
		btnCheckButton_10.setText("Visited ICU for COPD in Last Year");
		btnCheckButton_10.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnSmoker = new Button(shell, SWT.CHECK);
		btnSmoker.setBounds(22, 285, 93, 16);
		btnSmoker.setText("Anemia");
		btnSmoker.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_11 = new Button(shell, SWT.CHECK);
		btnCheckButton_11.setBounds(22, 307, 93, 16);
		btnCheckButton_11.setText("Smoker");
		btnCheckButton_11.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_12 = new Button(shell, SWT.CHECK);
		btnCheckButton_12.setBounds(203, 286, 153, 16);
		btnCheckButton_12.setText("Congestive Heart Failure");
		btnCheckButton_12.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		Button btnCheckButton_13 = new Button(shell, SWT.CHECK);
		btnCheckButton_13.setBounds(203, 308, 153, 16);
		btnCheckButton_13.setText("Long Term Oxygen User");
		btnCheckButton_13.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
	Button btnCheckButton_15 = new Button(shell, SWT.CHECK);
		btnCheckButton_15.setBounds(412, 285, 93, 16);
		btnCheckButton_15.setText("Unknown");
		btnCheckButton_15.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		
		
		
		Label lblProfileSeverity = new Label(shell, SWT.NONE);
		lblProfileSeverity.setText("Profile Severity:");
		lblProfileSeverity.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblProfileSeverity.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblProfileSeverity.setBounds(22, 455, 103, 20);
		
		Combo profs = new Combo(shell, SWT.NONE);
		profs.setBackground(SWTResourceManager.getColor(204, 255, 255));
		profs.setBounds(173, 452, 65, 23);
		profs.add("1");
		profs.add("2");
		profs.add("3");
		profs.add("4");
		profs.add("5");
		profs.setText("1");
		
		
	
		
		
		
		ArrayList<Button> risks = new ArrayList<Button>(18);
		risks.add(btnCheckButton);
		risks.add(btnAsthma);
		risks.add(btnCheckButton_1);
		risks.add(btnCheckButton_2);
		risks.add(btnCheckButton_3);
		risks.add(btnCheckButton_4);
		risks.add(btnCheckButton_5);
		risks.add(btnCheckButton_6);
		risks.add(btnCheckButton_7);
		risks.add(btnCheckButton_8);
		risks.add(btnCheckButton_9);
		risks.add(btnCheckButton_10);
		risks.add(btnCheckButton_11);
		risks.add(btnCheckButton_12);
		risks.add(btnCheckButton_13);
		risks.add(btnCheckButton_15);
		risks.add(btnSmoker);
	
		Button btnNewButton = new Button(shell, SWT.NONE);
		btnNewButton.setForeground(SWTResourceManager.getColor(255, 0, 0));
		btnNewButton.setFont(SWTResourceManager.getFont("Andalus", 13, SWT.BOLD));
		btnNewButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				record.setGender(gender.getItem(gender.getSelectionIndex()));
				record.setHeight(Integer.parseInt(height.getText()));
				record.setWeight(Integer.parseInt(weight.getText()));
				record.setAge(Integer.parseInt(age.getText()));
			  //  record.setCurrentMedication(currMed.getItem(bsdys.getSelectionIndex()));
			    record.setCopdStage(copdStage.getItem(copdStage.getSelectionIndex()));
			    record.setProfSeverity(Integer.parseInt(profs.getItem(profs.getSelectionIndex())));
			   
			    
				int bmi = findBMI(Integer.parseInt(height.getText()),Integer.parseInt(weight.getText()));
				record.setBmi(bmi);
				//label.setText(Integer.toString(bmi));
				
				
				String risk1="",risk2="",risk3="",risk4=""; int n=0;
				for (Button btn : risks)
				{
					if (btn.getSelection() == true){
						n++;
						if ( n == 5){
							riskOnly4 r = new riskOnly4();
							r.only4();
						}
						if(risk1.equals(""))
							risk1 = btn.getText();
						else
							if (risk2.equals(""))
								risk2 =  btn.getText();
							else
								if (risk3.equals(""))
									risk3 =  btn.getText();
								else
									if (risk4.equals(""))
										risk4 =  btn.getText(); 
					
					}
				}
				if (risk1.equals(""))
					risk1 = "Unknown";
				if (risk2.equals(""))
					risk2 = "Unknown";
				if (risk3.equals(""))
					risk3 = "Unknown";
				if (risk4.equals(""))
					risk4 = "Unknown";
				
				record.setRisk1(risk1);record.setRisk2(risk2);record.setRisk3(risk3);record.setRisk4(risk4);
				Symptoms s = new Symptoms();
				s.goToSymptoms();
			}
		});
		btnNewButton.setBackground(SWTResourceManager.getColor(204, 255, 255));
		btnNewButton.setBounds(621, 473, 112, 37);
		btnNewButton.setText("Continue\r\n");
		
		
	

	}
}
