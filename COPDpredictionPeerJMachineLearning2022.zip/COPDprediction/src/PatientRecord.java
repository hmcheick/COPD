
class PatientRecord{
	
	public PatientRecord() {
		
	}


	


	private String gender;
	private int age, height, weight, bmi, baseFEV1, baseHeartRate, basePulse, profSeverity,curHeartRate, curPulse, baseFEV1predicted,curFEV1predicted, curTemp, vitalSeverity, sympSeverity;
	private String risk1, risk2, risk3, risk4;
	private String currentMedication, baseDyspnea, copdStage;	
	private String recentSym, controller, shortBreath, cough, wheezing, sputum, currentDysp,infection, respSym;
	private String alternateDiag;
	public PatientRecord(String gender, int age, int height, int weight,
			int bmi, int baseFEV1, int baseHeartRate, int basePulse,
			int profSeverity, int curHeartRate, int curPulse,
			int baseFEV1predicted, int curFEV1predicted, int curTemp,
			int vitalSeverity, int sympSeverity, String risk1, String risk2,
			String risk3, String risk4, String currentMedication,
			String baseDyspnea, String copdStage, String recentSym,
			String controller, String shortBreath, String cough,
			String wheezing, String sputum, String currentDysp,
			String infection, String respSym, String alternateDiag) {
		super();
		this.gender = gender;
		this.age = age;
		this.height = height;
		this.weight = weight;
		this.bmi = bmi;
		this.baseFEV1 = baseFEV1;
		this.baseHeartRate = baseHeartRate;
		this.basePulse = basePulse;
		this.profSeverity = profSeverity;
		this.curHeartRate = curHeartRate;
		this.curPulse = curPulse;
		this.baseFEV1predicted = baseFEV1predicted;
		this.curFEV1predicted = curFEV1predicted;
		this.curTemp = curTemp;
		this.vitalSeverity = vitalSeverity;
		this.sympSeverity = sympSeverity;
		this.risk1 = risk1;
		this.risk2 = risk2;
		this.risk3 = risk3;
		this.risk4 = risk4;
		this.currentMedication = currentMedication;
		this.baseDyspnea = baseDyspnea;
		this.copdStage = copdStage;
		this.recentSym = recentSym;
		this.controller = controller;
		this.shortBreath = shortBreath;
		this.cough = cough;
		this.wheezing = wheezing;
		this.sputum = sputum;
		this.currentDysp = currentDysp;
		this.infection = infection;
		this.respSym = respSym;
		this.alternateDiag = alternateDiag;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getBmi() {
		return bmi;
	}
	public void setBmi(int bmi) {
		this.bmi = bmi;
	}
	public int getBaseFEV1() {
		return baseFEV1;
	}
	public void setBaseFEV1(int baseFEV1) {
		this.baseFEV1 = baseFEV1;
	}
	public int getBaseHeartRate() {
		return baseHeartRate;
	}
	public void setBaseHeartRate(int baseHeartRate) {
		this.baseHeartRate = baseHeartRate;
	}
	public int getBasePulse() {
		return basePulse;
	}
	public void setBasePulse(int basePulse) {
		this.basePulse = basePulse;
	}
	public int getProfSeverity() {
		return profSeverity;
	}
	public void setProfSeverity(int profSeverity) {
		this.profSeverity = profSeverity;
	}
	public int getCurHeartRate() {
		return curHeartRate;
	}
	public void setCurHeartRate(int curHeartRate) {
		this.curHeartRate = curHeartRate;
	}
	public int getCurPulse() {
		return curPulse;
	}
	public void setCurPulse(int curPulse) {
		this.curPulse = curPulse;
	}
	public int getBaseFEV1predicted() {
		return baseFEV1predicted;
	}
	public void setBaseFEV1predicted(int baseFEV1predicted) {
		this.baseFEV1predicted = baseFEV1predicted;
	}
	public int getCurFEV1predicted() {
		return curFEV1predicted;
	}
	public void setCurFEV1predicted(int curFEV1predicted) {
		this.curFEV1predicted = curFEV1predicted;
	}
	public int getCurTemp() {
		return curTemp;
	}
	public void setCurTemp(int curTemp) {
		this.curTemp = curTemp;
	}
	public int getVitalSeverity() {
		return vitalSeverity;
	}
	public void setVitalSeverity(int vitalSeverity) {
		this.vitalSeverity = vitalSeverity;
	}
	public int getSympSeverity() {
		return sympSeverity;
	}
	public void setSympSeverity(int sympSeverity) {
		this.sympSeverity = sympSeverity;
	}
	public String getRisk1() {
		return risk1;
	}
	public void setRisk1(String risk1) {
		this.risk1 = risk1;
	}
	public String getRisk2() {
		return risk2;
	}
	public void setRisk2(String risk2) {
		this.risk2 = risk2;
	}
	public String getRisk3() {
		return risk3;
	}
	public void setRisk3(String risk3) {
		this.risk3 = risk3;
	}
	public String getRisk4() {
		return risk4;
	}
	public void setRisk4(String risk4) {
		this.risk4 = risk4;
	}
	public String getCurrentMedication() {
		return currentMedication;
	}
	public void setCurrentMedication(String currentMedication) {
		this.currentMedication = currentMedication;
	}
	public String getBaseDyspnea() {
		return baseDyspnea;
	}
	public void setBaseDyspnea(String baseDyspnea) {
		this.baseDyspnea = baseDyspnea;
	}
	public String getCopdStage() {
		return copdStage;
	}
	public void setCopdStage(String copdStage) {
		this.copdStage = copdStage;
	}
	public String getRecentSym() {
		return recentSym;
	}
	public void setRecentSym(String recentSym) {
		this.recentSym = recentSym;
	}
	public String getController() {
		return controller;
	}
	public void setController(String controller) {
		this.controller = controller;
	}
	public String getShortBreath() {
		return shortBreath;
	}
	public void setShortBreath(String shortBreath) {
		this.shortBreath = shortBreath;
	}
	public String getCough() {
		return cough;
	}
	public void setCough(String cough) {
		this.cough = cough;
	}
	public String getWheezing() {
		return wheezing;
	}
	public void setWheezing(String wheezing) {
		this.wheezing = wheezing;
	}
	public String getSputum() {
		return sputum;
	}
	public void setSputum(String sputum) {
		this.sputum = sputum;
	}
	public String getCurrentDysp() {
		return currentDysp;
	}
	public void setCurrentDysp(String currentDysp) {
		this.currentDysp = currentDysp;
	}
	public String getInfection() {
		return infection;
	}
	public void setInfection(String infection) {
		this.infection = infection;
	}
	public String getRespSym() {
		return respSym;
	}
	public void setRespSym(String respSym) {
		this.respSym = respSym;
	}
	public String getAlternateDiag() {
		return alternateDiag;
	}
	public void setAlternateDiag(String alternateDiag) {
		this.alternateDiag = alternateDiag;
	}
	
	
	


	

}