import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;


public class Predict {

	protected Shell shell;

	/**
	 * Launch the application.
	 * @param args
	 * @wbp.parser.entryPoint
	 */
	
	
	public static void predict() {
		try {
			Predict window = new Predict();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		shell.setSize(835, 559);
		shell.setText("SWT Application");
		
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setAlignment(SWT.CENTER);
		lblNewLabel.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblNewLabel.setFont(SWTResourceManager.getFont("Andalus", 16, SWT.BOLD));
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblNewLabel.setBounds(274, 0, 243, 37);
		lblNewLabel.setText("Results");
		
		Label label1 = new Label(shell, SWT.NONE);
		label1.setFont(SWTResourceManager.getFont("Calibri", 10, SWT.BOLD));
		label1.setBackground(SWTResourceManager.getColor(204, 255, 255));
		label1.setBounds(10, 43, 472, 480);
		String result =  "Gender: " + Start.getRecord().getGender() +"\nHeight: "+ Start.getRecord().getHeight() + 
				"\nWeight: "+ Start.getRecord().getWeight()+
				"\nAge: "+ Start.getRecord().getAge()+
			//	"\nBaseline Heart Rate: "+Start.getRecord().getBaseHeartRate()+
                "\nCurrent Heart Rate: "+ Start.getRecord().getCurHeartRate()+
			//	"\nBaseline Pulse: "+Start.getRecord().getBasePulse()+
				"\nCurrent Pulse: "+ Start.getRecord().getCurPulse()+
			//	"\nBaseline FEV1: "+Start.getRecord().getBaseFEV1()+
				"\nRisk Factors: "+Start.getRecord().getRisk1()+
				"\n                 "+Start.getRecord().getRisk2()+
				"\n                 "+Start.getRecord().getRisk3()+
				"\n                 "+Start.getRecord().getRisk4()+
				//"\nBaseline Dyspnea: "+Start.getRecord().getBaseDyspnea()+
				"\nCurrent Dyspnea: "+ Start.getRecord().getCurrentDysp()+
				"\nCurrent Medication: "+Start.getRecord().getCurrentMedication()+
				"\nCurrent Temperature: "+ Start.getRecord().getCurTemp()+				
				"\nCurrent FEV1 (predicted): "+ Start.getRecord().getCurFEV1predicted()+
				//"\nBaseline FEV1 (predicted): "+ Start.getRecord().getBaseFEV1predicted()+
				"\nCOPD GOLD Stage: "+Start.getRecord().getCopdStage()+
				
				"\nRecent Worsening Symptoms?: "+ Start.getRecord().getRecentSym()+
				"\nWake up at night more than usual? "+ Start.getRecord().getRespSym()+
				"\nMedication taken over last week? "+ Start.getRecord().getController()+
				"\nShort of breath? "+ Start.getRecord().getShortBreath()+
				"\nCough? "+Start.getRecord().getCough()+
				"\nWheezing? "+ Start.getRecord().getWheezing()+
				"\nSputum? "+Start.getRecord().getSputum()+
				"\nInfection: "+ Start.getRecord().getInfection()+
				"\nProfile Severity: "+Start.getRecord().getProfSeverity()+
				"\nSymptom Severity: "+ Start.getRecord().getSympSeverity()+
				"\nVitals Severity: "+ Start.getRecord().getVitalSeverity()
				;
		label1.setText(result);
		
		Label lblBasedOnThe = new Label(shell, SWT.NONE);
		lblBasedOnThe.setForeground(SWTResourceManager.getColor(SWT.COLOR_DARK_MAGENTA));
		lblBasedOnThe.setFont(SWTResourceManager.getFont("Calibri", 10, SWT.BOLD));
		lblBasedOnThe.setBackground(SWTResourceManager.getColor(204, 255, 255));
		lblBasedOnThe.setBounds(500, 43, 289, 443);
		
		
		
		ExaReader er = new ExaReader();
		RecReader rec = new RecReader();
		String recr = ""; 
		try {
			 recr = rec.getResult();
			
			if (recr.equals("1"))
				recr= "Ok: No additional medical attention needed";
			if (recr.equals("2"))
				recr= "Plan: Continue treatment and check back in 1-2 days";
			if (recr.equals("3"))
				recr= "Doc: Call the doctor";
			if (recr.equals("4"))
				recr= "ER: Go to the emergency room";
			     
		} catch (InvalidFormatException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		try {
			String x = er.getResult(Start.getRecord());
			if (x.equals("Y"))
				lblBasedOnThe.setText("After analyzing your profile we can tell you that: \n you have an exacerbation \n you can follow the below recommendation \n \n \n" + recr);
			if (x.equals("N"))
				lblBasedOnThe.setText("After analyzing your profile we can tell you that: \n you have NO exacerbation \n you can see the below recommendation \n \n \n" + recr);

		} catch (InvalidFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
