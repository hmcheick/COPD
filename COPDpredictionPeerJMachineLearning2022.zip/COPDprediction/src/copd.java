

import javax.swing.ImageIcon;

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.SWT;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.jface.databinding.swt.WidgetProperties;
import org.eclipse.core.databinding.beans.PojoProperties;
import org.eclipse.core.databinding.observable.Realm;
import org.eclipse.jface.databinding.swt.SWTObservables;


public class copd {
	private DataBindingContext m_bindingContext;

	protected Shell shell;
	private Button btnStartPrediction;

	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		Display display = Display.getDefault();
		Realm.runWithDefault(SWTObservables.getRealm(display), new Runnable() {
			public void run() {
				try {
					copd window = new copd();
					window.open();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setMinimumSize(new Point(150, 60));
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		shell.setSize(835, 559);
		shell.setText("SWT Application");
		
		Label lblWelcomeToCopd = new Label(shell, SWT.NONE);
		lblWelcomeToCopd.setAlignment(SWT.CENTER);
		lblWelcomeToCopd.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblWelcomeToCopd.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblWelcomeToCopd.setToolTipText("");
		lblWelcomeToCopd.setFont(SWTResourceManager.getFont("Andalus", 22, SWT.BOLD));
		lblWelcomeToCopd.setText("WELCOME \r\nTO");
		lblWelcomeToCopd.setBounds(330, 86, 197, 104);
		
		Label lblCopdExacerbationPrediction = new Label(shell, SWT.NONE);
		lblCopdExacerbationPrediction.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCopdExacerbationPrediction.setFont(SWTResourceManager.getFont("Andalus", 22, SWT.BOLD));
		lblCopdExacerbationPrediction.setAlignment(SWT.CENTER);
		lblCopdExacerbationPrediction.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblCopdExacerbationPrediction.setText("COPD EXACERBATION PREDICTNG AND TRIAGING APPLICATION");
		lblCopdExacerbationPrediction.setBounds(80, 185, 671, 115);
		
		btnStartPrediction = new Button(shell, SWT.NONE);
		btnStartPrediction.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Start p = new Start();
				p.NewScreen();
			}
		});
		btnStartPrediction.setFont(SWTResourceManager.getFont("Andalus", 20, SWT.BOLD));
		btnStartPrediction.setBounds(342, 307, 168, 51);
		btnStartPrediction.setText("Start");
		m_bindingContext = initDataBindings();
		//Image img = new Image(null, "C:\\Users\\user\\workspace\\COPDprediction\\img\\lungs-icon");
		//ImageIcon img = new ImageIcon();
		//lblNewLabel.

	}
	protected DataBindingContext initDataBindings() {
		DataBindingContext bindingContext = new DataBindingContext();
		//
		IObservableValue observeBackgroundBtnStartPredictionObserveWidget = WidgetProperties.background().observe(btnStartPrediction);
		IObservableValue backgroundblueShellObserveValue = PojoProperties.value("background.blue").observe(shell);
		bindingContext.bindValue(observeBackgroundBtnStartPredictionObserveWidget, backgroundblueShellObserveValue, null, null);
		//
		return bindingContext;
	}
}
