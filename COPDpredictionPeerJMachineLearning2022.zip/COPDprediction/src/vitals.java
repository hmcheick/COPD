import java.io.File;
import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;

import com.rapidminer.Process;
import com.rapidminer.RapidMiner;
import com.rapidminer.operator.OperatorException;
import com.rapidminer.tools.XMLException;


public class vitals {

	protected Shell shell;
	private Text chr;
	private Text cp;
	private Text cf;
	private Text ct;

	/**
	 * Launch the application.
	 * @param args
	 * @wbp.parser.entryPoint
	 */
	public static void goToVitals() {
		try {
			vitals window = new vitals();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		shell.setSize(835, 559);
		shell.setText("SWT Application");
		
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setAlignment(SWT.CENTER);
		lblNewLabel.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblNewLabel.setFont(SWTResourceManager.getFont("Andalus", 16, SWT.BOLD));
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblNewLabel.setBounds(269, 27, 243, 37);
		lblNewLabel.setText("Vitals");
		
		Combo vs = new Combo(shell, SWT.NONE);
		vs.setBackground(SWTResourceManager.getColor(204, 255, 255));
		vs.setBounds(156, 288, 65, 23);
		vs.setText("1");
		vs.add("1");
		vs.add("2");
		vs.add("3");
		vs.add("4");
		vs.add("5");
		
		Combo combo = new Combo(shell, SWT.NONE);
		combo.setBackground(SWTResourceManager.getColor(204, 255, 255));
		combo.setBounds(203, 238, 65, 23);
		combo.setText("Yes");
		combo.add("Yes");
		combo.add("No");
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				Start.getRecord().setCurFEV1predicted(Integer.parseInt(cf.getText()));
				Start.getRecord().setCurHeartRate(Integer.parseInt(chr.getText()));
				Start.getRecord().setCurPulse(Integer.parseInt(cp.getText()));
				Start.getRecord().setCurTemp(Integer.parseInt(ct.getText()));
				Start.getRecord().setAlternateDiag(combo.getItem(combo.getSelectionIndex()));
				Start.getRecord().setVitalSeverity(Integer.parseInt(vs.getItem(vs.getSelectionIndex())));

				ExaWriter ex = new ExaWriter();
				try {
					ex.addRecord(Start.getRecord());
				} catch (InvalidFormatException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				
				 try {
			    	   
			           RapidMiner.setExecutionMode(RapidMiner.ExecutionMode.COMMAND_LINE);
			           RapidMiner.init();
			           Process process = new Process(new File("C:\\Users\\user\\.RapidMiner\\repositories\\Local Repository\\processes\\Predict-Exa.rmp"));
			           process.run();
			           
			          } catch (IOException ex1) {
			           ex1.printStackTrace();
			} catch (Throwable e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				 
				    ExaReader er = new ExaReader();
					RecWriter rec = new RecWriter();
					
					try {
						rec.addRecord(Start.getRecord(),er.getResult(Start.getRecord()) );
					} catch (InvalidFormatException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
					
					try {
				    	   
				           RapidMiner.setExecutionMode(RapidMiner.ExecutionMode.COMMAND_LINE);
				           RapidMiner.init();
				           Process process = new Process(new File("C:\\Users\\user\\.RapidMiner\\repositories\\Local Repository\\processes\\Predict-Rec.rmp"));
				           process.run();
				           
				          } catch (IOException ex1) {
				           ex1.printStackTrace();
				} catch (Throwable e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
				 
				
				Predict p = new Predict();
				p.predict();
				
				
			}
		});
		button.setText("Predict\r\n");
		button.setForeground(SWTResourceManager.getColor(255, 0, 0));
		button.setFont(SWTResourceManager.getFont("Andalus", 13, SWT.BOLD));
		button.setBackground(SWTResourceManager.getColor(204, 255, 255));
		button.setBounds(634, 440, 112, 37);
		
		Label lblCurrentHeratRate = new Label(shell, SWT.NONE);
		lblCurrentHeratRate.setText("Current Heart Rate:");
		lblCurrentHeratRate.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCurrentHeratRate.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCurrentHeratRate.setBounds(44, 76, 129, 20);
		
		Label lblCurrentPulse = new Label(shell, SWT.NONE);
		lblCurrentPulse.setText("Current Pulse:");
		lblCurrentPulse.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCurrentPulse.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCurrentPulse.setBounds(44, 114, 99, 32);
		
		chr = new Text(shell, SWT.BORDER);
		chr.setBackground(SWTResourceManager.getColor(204, 255, 255));
		chr.setBounds(179, 71, 61, 25);
		
		cp = new Text(shell, SWT.BORDER);
		cp.setBackground(SWTResourceManager.getColor(204, 255, 255));
		cp.setBounds(156, 107, 61, 25);
		
		Label lblCurrentFevpredicted = new Label(shell, SWT.NONE);
		lblCurrentFevpredicted.setText("Current FEV1 (predicted):");
		lblCurrentFevpredicted.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCurrentFevpredicted.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCurrentFevpredicted.setBounds(44, 152, 184, 32);
		
		cf = new Text(shell, SWT.BORDER);
		cf.setBackground(SWTResourceManager.getColor(204, 255, 255));
		cf.setBounds(234, 152, 61, 25);
		
		ct = new Text(shell, SWT.BORDER);
		ct.setBackground(SWTResourceManager.getColor(204, 255, 255));
		ct.setBounds(207, 190, 61, 25);
		
		Label lblCurrentTemperature = new Label(shell, SWT.NONE);
		lblCurrentTemperature.setText("Current Temperature:");
		lblCurrentTemperature.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCurrentTemperature.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCurrentTemperature.setBounds(44, 190, 157, 32);
		
		Label lblVitalsSeverity = new Label(shell, SWT.NONE);
		lblVitalsSeverity.setText("Vitals Severity:");
		lblVitalsSeverity.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblVitalsSeverity.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblVitalsSeverity.setBounds(44, 288, 103, 20);
		
		Label lblAlternateDiagnosis = new Label(shell, SWT.NONE);
		lblAlternateDiagnosis.setText("Alternate Diagnosis?");
		lblAlternateDiagnosis.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblAlternateDiagnosis.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblAlternateDiagnosis.setBounds(44, 241, 157, 20);
		
	
		
		
		
		

	}
}
