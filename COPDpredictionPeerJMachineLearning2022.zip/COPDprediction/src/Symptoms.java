

import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

public class Symptoms {

	protected Shell shell;

	/**
	 * Launch the application.
	 * @param args
	 * @wbp.parser.entryPoint
	 */
	public static void goToSymptoms() {
		try {
			Symptoms window = new Symptoms();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shell = new Shell();
		shell.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		shell.setSize(835, 559);
		shell.setText("SWT Application");
		
		Label lblNewLabel = new Label(shell, SWT.NONE);
		lblNewLabel.setAlignment(SWT.CENTER);
		lblNewLabel.setForeground(SWTResourceManager.getColor(SWT.COLOR_RED));
		lblNewLabel.setFont(SWTResourceManager.getFont("Andalus", 16, SWT.BOLD));
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblNewLabel.setBounds(269, 27, 243, 37);
		lblNewLabel.setText("Symptoms");
		
		Label lblNewLabel_1 = new Label(shell, SWT.NONE);
		lblNewLabel_1.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblNewLabel_1.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblNewLabel_1.setBounds(32, 112, 204, 32);
		lblNewLabel_1.setText("Recent Worsening Symptoms:");
		
		Label lblControllerMedicationTaken = new Label(shell, SWT.NONE);
		lblControllerMedicationTaken.setText("Controller Medication taken over last week:\r\n");
		lblControllerMedicationTaken.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblControllerMedicationTaken.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblControllerMedicationTaken.setBounds(32, 188, 296, 32);
		
		Combo con = new Combo(shell, SWT.NONE);
		con.setBackground(SWTResourceManager.getColor(204, 255, 255));
		con.setBounds(322, 192, 166, 23);
		con.setText("Less Than Usual");
		con.add("Less Than Usual");
		con.add("More Than Usual");
		con.add("Same As Usual");
			
		
		Label lblShortOfBreath = new Label(shell, SWT.NONE);
		lblShortOfBreath.setText("Short of breath:");
		lblShortOfBreath.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblShortOfBreath.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblShortOfBreath.setBounds(32, 226, 112, 32);
		
		Combo sho = new Combo(shell, SWT.NONE);
		sho.setBackground(SWTResourceManager.getColor(204, 255, 255));
		sho.setBounds(142, 226, 166, 23);
		sho.setText("Less Than Usual");
		sho.add("Less Than Usual");
		sho.add("More Than Usual");
		sho.add("Same As Usual");
		
		Label lblCough = new Label(shell, SWT.NONE);
		lblCough.setText("Cough:");
		lblCough.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCough.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCough.setBounds(32, 257, 112, 32);
		
		Combo cou = new Combo(shell, SWT.NONE);
		cou.setBackground(SWTResourceManager.getColor(204, 255, 255));
		cou.setBounds(142, 261, 166, 23);
		cou.setText("Less Than Usual");
		cou.add("Less Than Usual");
		cou.add("More Than Usual");
		cou.add("Same As Usual");
		
		Combo whee = new Combo(shell, SWT.NONE);
		whee.setBackground(SWTResourceManager.getColor(204, 255, 255));
		whee.setBounds(142, 299, 166, 23);
		whee.setText("Less Than Usual");
		whee.add("Less Than Usual");
		whee.add("More Than Usual");
		whee.add("Same As Usual");
		
		Combo spu = new Combo(shell, SWT.NONE);
		spu.setBackground(SWTResourceManager.getColor(204, 255, 255));
		spu.setBounds(142, 333, 166, 23);
		spu.setText("Less Than Usual");
		spu.add("Less Than Usual");
		spu.add("More Than Usual");
		spu.add("Same As Usual");
		
		Label lblWheezing = new Label(shell, SWT.NONE);
		lblWheezing.setText("Wheezing:");
		lblWheezing.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblWheezing.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblWheezing.setBounds(32, 295, 81, 32);
		
		Label lblSputum = new Label(shell, SWT.NONE);
		lblSputum.setText("Sputum:");
		lblSputum.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblSputum.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblSputum.setBounds(32, 329, 81, 32);
		
		Combo syms = new Combo(shell, SWT.NONE);
		syms.setBackground(SWTResourceManager.getColor(204, 255, 255));
		syms.setBounds(171, 443, 65, 23);
		syms.setText("1");
		syms.add("1");
		syms.add("2");
		syms.add("3");
		syms.add("4");
		syms.add("5");
		
		Label lblSymptomSeverity = new Label(shell, SWT.NONE);
		lblSymptomSeverity.setText("Symptom Severity:");
		lblSymptomSeverity.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblSymptomSeverity.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblSymptomSeverity.setBounds(32, 439, 133, 32);
		
		Label lblCurrentDyspnea = new Label(shell, SWT.NONE);
		lblCurrentDyspnea.setText("Current Dyspnea:");
		lblCurrentDyspnea.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblCurrentDyspnea.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblCurrentDyspnea.setBounds(32, 363, 133, 32);
		
		Combo dys = new Combo(shell, SWT.NONE);
		dys.setBackground(SWTResourceManager.getColor(204, 255, 255));
		dys.setBounds(171, 367, 453, 23);
		dys.setText("MMRC 1 (Breathless Only With Demanding Exercise");
		dys.add("MMRC 1 (Breathless Only With Demanding Exercise");
		dys.add("MMRC 2 (Breathless Only while Hurrying On Flat Ground");
		dys.add("MMRC 3 (Slowed Walking Speed Due To Breathlessness");
		dys.add("MMRC 4 (Stop to Breathe Every Few Minutes When Walking");
		dys.add("MMRC 5 (Too Breathless To Leave The House Or Breathless When Dressing");
		
		Label lblInfection = new Label(shell, SWT.NONE);
		lblInfection.setText("Infection:");
		lblInfection.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblInfection.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblInfection.setBounds(32, 401, 69, 23);
		
		Label lblRespiratorySymptomsWake = new Label(shell, SWT.NONE);
		lblRespiratorySymptomsWake.setText("Respiratory Symptoms Wake You Up At Night More Than Usual ?\r\n");
		lblRespiratorySymptomsWake.setFont(SWTResourceManager.getFont("Andalus", 12, SWT.NORMAL));
		lblRespiratorySymptomsWake.setBackground(SWTResourceManager.getColor(SWT.COLOR_CYAN));
		lblRespiratorySymptomsWake.setBounds(32, 150, 445, 32);
		
		Combo infect = new Combo(shell, SWT.NONE);
		infect.setBackground(SWTResourceManager.getColor(204, 255, 255));
		infect.setBounds(125, 405, 65, 23);
		infect.setText("Yes");
		infect.add("Yes");
		infect.add("No");
		
		Combo resp = new Combo(shell, SWT.NONE);
		resp.setBackground(SWTResourceManager.getColor(204, 255, 255));
		resp.setBounds(491, 154, 65, 23);
		resp.setText("Yes");
		resp.add("Yes");
		resp.add("No");
		
		Combo wor = new Combo(shell, SWT.NONE);
		wor.setBackground(SWTResourceManager.getColor(204, 255, 255));
		wor.setBounds(252, 112, 296, 23);
		wor.setText("No");
		wor.add("Yes");
		wor.add("No");
		
		
		Button button = new Button(shell, SWT.NONE);
		button.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				Start.getRecord().setController(con.getText());
				Start.getRecord().setCough(cou.getText());
				Start.getRecord().setShortBreath(sho.getText());
				Start.getRecord().setWheezing(whee.getText());
				Start.getRecord().setSputum(spu.getText());
				Start.getRecord().setRespSym(resp.getText());
				Start.getRecord().setRecentSym(wor.getText());
				Start.getRecord().setCurrentDysp(dys.getText());
				Start.getRecord().setInfection(infect.getText());				
				Start.getRecord().setSympSeverity(Integer.parseInt(syms.getItem(syms.getSelectionIndex())));

				vitals v = new vitals();
				v.goToVitals();
			}
		});
		button.setText("Continue\r\n");
		button.setForeground(SWTResourceManager.getColor(255, 0, 0));
		button.setFont(SWTResourceManager.getFont("Andalus", 13, SWT.BOLD));
		button.setBackground(SWTResourceManager.getColor(204, 255, 255));
		button.setBounds(435, 473, 112, 37);
		
		

	}
}
