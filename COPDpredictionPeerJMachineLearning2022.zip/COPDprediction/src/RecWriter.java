import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by rajeevkumarsingh on 22/12/17.
 */

public class RecWriter {

    private static String[] columns = {"Profile Severity (1-5)","Recent Worsening in Symptoms?","Short of Breath","Cough","Wheezing","Sputum","Current Dyspnea (MMRC)","Infection",
    	"Respiratory Symptoms Wake You Up At Night More Than Usual","Symptom Severity (1-5)","Current Heart Rate","Current Pulse Ox","Current FEV1 (% Predicted)","Current Temperature","Vitals Severity (1-5)","Alternate Diagnosis","Exacerbation (Y/N)"};

   // private static List<PatientRecord> patientRecord =  new ArrayList<>();

    public void addRecord (PatientRecord record, String exa) throws IOException, InvalidFormatException {

        
        Workbook workbook = new XSSFWorkbook();     
        CreationHelper createHelper = workbook.getCreationHelper();
        Sheet sheet = workbook.createSheet("PatientRecord");
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.RED.getIndex());

        // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        // Create a Row
        Row headerRow = sheet.createRow(0);

        // Creating cells
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

        
            Row row = sheet.createRow(1);

           
            
            row.createCell(0).setCellValue(record.getProfSeverity());
            row.createCell(1).setCellValue(record.getRecentSym());
         //   row.createCell(2).setCellValue(record.getController());
            row.createCell(2).setCellValue(record.getShortBreath());
            row.createCell(3).setCellValue(record.getCough());
            row.createCell(4).setCellValue(record.getWheezing());
            row.createCell(5).setCellValue(record.getSputum());
            row.createCell(6).setCellValue(record.getCurrentDysp());
            row.createCell(7).setCellValue(record.getInfection());
            row.createCell(8).setCellValue(record.getRespSym());
            row.createCell(9).setCellValue(record.getSympSeverity());
            row.createCell(10).setCellValue(record.getCurHeartRate());
            row.createCell(11).setCellValue(record.getCurPulse());
            row.createCell(12).setCellValue(record.getCurFEV1predicted());
            row.createCell(13).setCellValue(record.getCurTemp());
            row.createCell(14).setCellValue(record.getVitalSeverity());
            row.createCell(15).setCellValue(record.getAlternateDiag());
            row.createCell(16).setCellValue(exa);
            
            
          
            
        // Resize all columns to fit the content size
        for(int i = 0; i < columns.length; i++) {
            sheet.autoSizeColumn(i);
        }

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream("C:\\Users\\user\\Desktop\\dataaaaaaaaaaa\\FINALLL\\Test-Rec.xlsx");
        workbook.write(fileOut);
        fileOut.close();

        workbook.close();
    }


    // Example to modify an existing excel file
    private static void modifyExistingWorkbook() throws InvalidFormatException, IOException {
        // Obtain a workbook from the excel file
        Workbook workbook = WorkbookFactory.create(new File("Test-Rec.xlsx"));

        // Get Sheet at index 0
        Sheet sheet = workbook.getSheetAt(0);

        // Get Row at index 1
        Row row = sheet.getRow(1);

        // Get the Cell at index 2 from the above row
        Cell cell = row.getCell(2);

        // Create the cell if it doesn't exist
        if (cell == null)
            cell = row.createCell(2);

        // Update the cell's value
        cell.setCellType(CellType.STRING);
        cell.setCellValue("Updated Value");

        // Write the output to a file
        FileOutputStream fileOut = new FileOutputStream("Test-Rec.xlsx");
        workbook.write(fileOut);
        fileOut.close();

        // Closing the workbook
        workbook.close();
    }
}



