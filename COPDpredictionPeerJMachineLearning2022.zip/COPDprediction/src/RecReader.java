
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;


public class RecReader {
    public static final String SAMPLE_XLSX_FILE_PATH = "C:\\Users\\user\\Desktop\\dataaaaaaaaaaa\\FINALLL\\Test-Rec.xlsx";

    public String getResult() throws IOException, InvalidFormatException {

        Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));

        Sheet sheet = workbook.getSheetAt(0);

        DataFormatter dataFormatter = new DataFormatter();

    
        
        String cellValue ="";
        String x = "";
      
        for (Row row: sheet) {
            for(Cell cell: row) {
                cellValue = dataFormatter.formatCellValue(cell);
                if (!cellValue.equalsIgnoreCase("")) x = cellValue;
               
            }
         
        }
        return x;

    
    }  
}
